﻿using NBD_Project.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NBD_Project.Data
{
    public class NBDSeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new NBDContext(
                serviceProvider.GetRequiredService<DbContextOptions<NBDContext>>()))
            {
                //Clients
                if (!context.Clients.Any())
                {
                    context.Clients.AddRange(
                    new Client
                    {
                        cltFName = "Kamalpreet",
                        cltMName = " ",
                        cltLName = "Kaur",
                        cltCity = "Niagara Falls",
                        cltProvince = "Ontario",
                        cltPostal = "L5B3G8",
                        cltPhNum = "2899687458",
                        cltContact = "Mobile phone"
                    },
                    new Client
                    {
                        cltFName = "Ricky",
                        cltMName = " ",
                        cltLName = "Lee",
                        cltCity = "St. Catherines",
                        cltProvince = "Ontario",
                        cltPostal = "L5B3G8",
                        cltPhNum = "2899754852",
                        cltContact = "House phone"
                    },
                    new Client
                    {
                        cltFName = "Marcus",
                        cltMName = " ",
                        cltLName = "Santos",
                        cltCity = "Welland",
                        cltProvince = "Ontario",
                        cltPostal = "L5B3G8",
                        cltPhNum = "2899684232",
                        cltContact = "Mobile phone"
                    },
                    new Client
                    {
                        cltFName = "Usman",
                        cltMName = " ",
                        cltLName = "Nasir",
                        cltCity = "Toronto",
                        cltProvince = "Ontario",
                        cltPostal = "L5B3G8",
                        cltPhNum = "4089687458",
                        cltContact = "Mobile phone"
                    },
                    new Client
                    {
                        cltFName = "Gina",
                        cltMName = " ",
                        cltLName = "Oliveira",
                        cltCity = "Niagara Falls",
                        cltProvince = "Ontario",
                        cltPostal = "L5B3G8",
                        cltPhNum = "2899354125",
                        cltContact = "Mobile phone"
                    });
                    context.SaveChanges();
                }
                //Projects
                if (!context.Projects.Any())
                {
                    context.Projects.AddRange(
                    new Project
                    {
                        ProjectName = "Seaway Mall",
                        BeginDate = "2022-02-18",
                        CompDate = "2022-04-26",
                        ProjSite = "Main Entrance",
                        ClientID = context.Clients.FirstOrDefault(d => d.cltFName == "Kamalpreet" && d.cltLName == "Kaur").ID
                    },
                    new Project
                    {
                        ProjectName = "Domino's",
                        BeginDate = "2021-12-14",
                        CompDate = "2022-03-14",
                        ProjSite = "Kitchen",
                        ClientID = context.Clients.FirstOrDefault(d => d.cltFName == "Ricky" && d.cltLName == "Lee").ID
                    },
                    new Project
                    {
                        ProjectName = "Marcus Hotel",
                        BeginDate = "2022-01-02",
                        CompDate = "2022-05-03",
                        ProjSite = "Main Entance",
                        ClientID = context.Clients.FirstOrDefault(d => d.cltFName == "Marcus" && d.cltLName == "Santos").ID
                    },
                    new Project
                    {
                        ProjectName = "Usman Restaurant",
                        BeginDate = "2022-05-04",
                        CompDate = "2022-07-04",
                        ProjSite = "Kid's playground",
                        ClientID = context.Clients.FirstOrDefault(d => d.cltFName == "Usman" && d.cltLName == "Nasir").ID
                    },
                    new Project
                    {
                        ProjectName = "Gina's Pizza",
                        BeginDate = "2022-06-07",
                        CompDate = "2022-08-07",
                        ProjSite = "Dining area",
                        ClientID = context.Clients.FirstOrDefault(d => d.cltFName == "Gina" && d.cltLName == "Oliveira").ID
                    });
                    context.SaveChanges();
                }
            }
        }
    }
}
