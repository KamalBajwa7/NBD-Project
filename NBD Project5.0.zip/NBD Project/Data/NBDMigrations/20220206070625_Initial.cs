﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD_Project.Data.NBDMigrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clients",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    cltFName = table.Column<string>(maxLength: 30, nullable: false),
                    cltMName = table.Column<string>(maxLength: 30, nullable: false),
                    cltLName = table.Column<string>(maxLength: 30, nullable: false),
                    cltCity = table.Column<string>(maxLength: 30, nullable: false),
                    cltPostal = table.Column<string>(maxLength: 6, nullable: false),
                    cltProvince = table.Column<string>(maxLength: 30, nullable: false),
                    cltPhNum = table.Column<string>(maxLength: 10, nullable: false),
                    cltContact = table.Column<string>(maxLength: 70, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clients", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Project",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ProjectName = table.Column<string>(maxLength: 50, nullable: false),
                    BeginDate = table.Column<string>(nullable: false),
                    CompDate = table.Column<string>(nullable: false),
                    ProjSite = table.Column<string>(maxLength: 100, nullable: false),
                    ClientID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Project", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Project_Clients_ClientID",
                        column: x => x.ClientID,
                        principalTable: "Clients",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Project_ClientID",
                table: "Project",
                column: "ClientID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Project");

            migrationBuilder.DropTable(
                name: "Clients");
        }
    }
}
