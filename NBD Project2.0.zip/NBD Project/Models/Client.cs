﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NBD_Project.Models
{
    public class Client
    {
        public Client()
        {
            Projects = new HashSet<Project>();
        }
        public int ID { get; set; }

        [Display(Name = "Client")]
        public string FullName
        {
            get
            {
                return cltFName
                    + (string.IsNullOrEmpty(cltMName) ? " " :
                        (" " + (char?)cltMName[0] + ". ").ToUpper())
                    + cltLName;
            }
        }

        [Display(Name = "Phone")]
        public string PhoneFormatted
        {
            get
            {
                return "(" + cltPhNum.Substring(0, 3) + ") " + cltPhNum.Substring(3, 3) + "-" + cltPhNum[6..];
            }
        }

        [Required(ErrorMessage = "You cannot leave the first name blank.")]
        [StringLength(30, ErrorMessage = "First name cannot be more than 30 characters long.")]
        public string cltFName { get; set; }

        [Required(ErrorMessage = "You cannot leave the Middle name blank.")]
        [StringLength(30, ErrorMessage = "Middle name cannot be more than 30 characters long.")]
        public string cltMName { get; set; }

        [Required(ErrorMessage = "You cannot leave the Last name blank.")]
        [StringLength(30, ErrorMessage = "Last name cannot be more than 30 characters long.")]
        public string cltLName { get; set; }

        [Required(ErrorMessage = "You cannot leave the Address blank.")]
        [StringLength(100, ErrorMessage = "Address cannot be more than 100 characters long.")]
        public string cltAddress { get; set; }

        [Required(ErrorMessage = "You cannot leave the Phone Number blank.")]
        [RegularExpression("^\\d{10}$", ErrorMessage = "The Phone Number must be exactly 10 numeric digits.")]
        [StringLength(10, ErrorMessage = "The 10 digits for the Phone Number is required")]
        public string cltPhNum { get; set; }

        [Required(ErrorMessage = "You cannot leave the Contact Info blank.")]
        [StringLength(70, ErrorMessage = "Contact cannot be more than 70 characters long.")]
        public string cltContact { get; set; }

        public ICollection<Project> Projects { get; set; }
    }
}
