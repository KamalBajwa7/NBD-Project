﻿using NBD_Project.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NBD_Project.Data
{
    public class NBDSeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new NBDContext(
                serviceProvider.GetRequiredService<DbContextOptions<NBDContext>>()))
            {
                //Projects
                if (!context.Projects.Any())
                {
                    context.Projects.AddRange(
                    new Project
                    {
                        ProjectName = "Seaway Mall",
                        BeginDate = "2022-02-18",
                        CompDate = "2022-04-26",
                        ProjSite = "Main Entrance",
                    },
                    new Project
                    {
                        ProjectName = "Domino's",
                        BeginDate = "2021-12-14",
                        CompDate = "2022-03-14",
                        ProjSite = "Kitchen",
                    },
                    new Project
                    {
                        ProjectName = "Marcus Hotel",
                        BeginDate = "2022-01-02",
                        CompDate = "2022-05-03",
                        ProjSite = "Main Entance",
                    },
                    new Project
                    {
                        ProjectName = "Usman Restaurant",
                        BeginDate = "2022-05-04",
                        CompDate = "2022-07-04",
                        ProjSite = "Kid's playground",
                    },
                    new Project
                    {
                        ProjectName = "Gina's Pizza",
                        BeginDate = "2022-06-07",
                        CompDate = "2022-08-07",
                        ProjSite = "Dining area",
                    });
                    context.SaveChanges();
                }

            }
        }
    }
}
