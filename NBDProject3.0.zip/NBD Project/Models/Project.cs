﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NBD_Project.Models
{
    public class Project
    {
        public int ID { get; set; }

        [Display(Name = "Project Name")]
        [Required(ErrorMessage = "You cannot leave the project name blank.")]
        [StringLength(50, ErrorMessage = "Project name cannot be more than 50 characters long.")]
        public string ProjectName { get; set; }

        [Display(Name = "Beginning Date")]
        [Required(ErrorMessage = "You must enter the beginning day.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public string BeginDate { get; set; }

        [Display(Name = "Completion Date")]
        [Required(ErrorMessage = "You must enter the completion day.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public string CompDate { get; set; }

        [Display(Name = "Project Site")]
        [Required(ErrorMessage = "You must enter the site.")]
        [StringLength(100, ErrorMessage = "Site cannot be more than 100 characters long.")]
        public string ProjSite { get; set; }

        /*[Required(ErrorMessage = "You must select a Bid.")]
        [Display(Name = "Bid")]
        public int BidID { get; set; }
        public Bid Bid { get; set; }

        [Required(ErrorMessage = "You must select a staff representant.")]
        [Display(Name = "Staff representant")]
        public int StaffID { get; set; }
        public Staff Staff { get; set; }*/

        [Display(Name = "Client")]
        [Required(ErrorMessage = "You must select the Client.")]
        public int ClientID { get; set; }
        public Client Client { get; set; }
    }
}
